package com.retail.product.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.retail.product.model.Product;

public interface ProductDAO extends JpaRepository<Product, Integer> {

	List<Product> findByNameIgnoreCaseContaining(String name);

}
