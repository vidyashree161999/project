package com.retail.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retail.product.client.AuthClient;
import com.retail.product.exception.AccessUnauthorizedException;
import com.retail.product.exception.ProductNotFoundException;
import com.retail.product.model.Product;
import com.retail.product.service.ProductService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@Slf4j
public class ProductController {

	@Autowired
	private ProductService productService;
	@Autowired
	private AuthClient authClient;

	/// search product by id
	@GetMapping("/searchProductById/{id}")
	public ResponseEntity<Product> searchProductById(@RequestHeader("Authorization") String token,@PathVariable("id") int id) throws ProductNotFoundException, AccessUnauthorizedException {
		log.debug("inside searchProductById() method");
		if(authClient.getValidity(token)==false)
		{
			throw new AccessUnauthorizedException("Invalid token");
		}
		Optional<Product> product = productService.getProductId(id);
		if (!product.isPresent())
			throw new ProductNotFoundException("Product with id=:" + id + " was not found.");
		return new ResponseEntity<Product>(product.get(), HttpStatus.OK);

	}

	@GetMapping("/test")
	public String test() {
		return "OK";
	}

	// search product by name
	@GetMapping("/searchProductByName/{name}")
	public ResponseEntity<List<Product>> searchProductByName(@RequestHeader("Authorization") String token,@PathVariable("name") String name)
			throws ProductNotFoundException, AccessUnauthorizedException {
		log.debug("inside searchProductByName() method");
		if(authClient.getValidity(token)==false)
		{
			throw new AccessUnauthorizedException("Invalid token");
		}
		List<Product> product = productService.getProductName(name);
		if (product.isEmpty())
			throw new ProductNotFoundException("Product with name=:" + name + " was not found.");
		return new ResponseEntity<List<Product>>(product, HttpStatus.OK);

	}

	// get rating from the user
	@PostMapping("/addProductRating/{id}/{rating}")
	public ResponseEntity<String> addProductRating(@RequestHeader("Authorization") String token,@PathVariable("id") int id, @PathVariable("rating") float rating)
			throws ProductNotFoundException, AccessUnauthorizedException {
		log.debug("inside searchProductByName() method");
		if(authClient.getValidity(token)==false)
		{
			throw new AccessUnauthorizedException("Invalid token");
		}
		productService.addRatings(id, rating);
		return new ResponseEntity<String>("Rating submitted successfully.", HttpStatus.OK);
	}

	// add a product to the database
	@PostMapping(value = "/addproduct")
	public ResponseEntity<String> createProduct(@RequestHeader("Authorization") String token,@RequestBody Product product) throws AccessUnauthorizedException {
		log.debug("inside createProduct() method");
		if(authClient.getValidity(token)==false)
		{
			throw new AccessUnauthorizedException("Invalid token");
		}
		productService.addProduct(product);
		return new ResponseEntity<String>("Product added successfully",HttpStatus.CREATED);
	}

	// get list of al the products
	@GetMapping(value = "/getproducts")
	public ResponseEntity<List<Product>> getProducts(@RequestHeader("Authorization") String token) throws ProductNotFoundException, AccessUnauthorizedException {
		log.debug("inside getProducts() method");
		if(authClient.getValidity(token)==false)
		{
			throw new AccessUnauthorizedException("Invalid token");
		}
		List<Product> list = productService.getProducts();
		if(list.isEmpty())
			throw new ProductNotFoundException("No products were found");
		return new ResponseEntity<>(list,HttpStatus.OK);
	}

}
