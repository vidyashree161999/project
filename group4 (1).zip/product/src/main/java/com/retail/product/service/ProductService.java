package com.retail.product.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.retail.product.DAO.ProductDAO;
import com.retail.product.exception.AlreadyExistException;
import com.retail.product.exception.ProductNotFoundException;
import com.retail.product.model.Product;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProductService {

	@Autowired
	ProductDAO dao;

	public Optional<Product> getProductId(int id) {
		log.info("id:{}",id);
		return dao.findById(id);
	}

	public List<Product> getProductName(String name) {
		log.info("name:{}",name);
		return dao.findByNameIgnoreCaseContaining(name);
	}

	public void addRatings(int id, float rating) throws ProductNotFoundException {
		log.info("id:{} rating:{}",id,rating);
		if (!getProductId(id).isPresent())
			throw new ProductNotFoundException(id + "not found");
		Product product = getProductId(id).get();
		float avgRating = product.getRating();
		int count = product.getCount();
		float avg = (avgRating * count + rating) / (count + 1);
		product.setRating(avg);
		product.setCount(count + 1);
		dao.save(product);
		log.info("addRatings() service ends");
	}

	public List<Product> getProducts() {
		log.info("inside getAllproducts() service");
		return (List<Product>) dao.findAll();
	}

	public void addProduct(Product product) {
		log.info("product:{}",product);
		if (getProductId(product.getId()).isPresent())
			throw new AlreadyExistException("Product already exist!");
		dao.save(product);
		
	}
}