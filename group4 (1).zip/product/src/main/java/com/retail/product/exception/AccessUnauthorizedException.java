
package com.retail.product.exception;

public class AccessUnauthorizedException extends Exception {

	
	public AccessUnauthorizedException() {
	}

	
	public AccessUnauthorizedException(String message) {
		super(message);

	}

	
	public AccessUnauthorizedException(Throwable cause) {
		super(cause);

	}

	
	public AccessUnauthorizedException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public AccessUnauthorizedException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
