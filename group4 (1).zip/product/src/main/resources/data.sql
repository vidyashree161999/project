INSERT INTO "PUBLIC"."PRODUCT"("ID","COUNT","DESCRIPTION","IMAGE_NAME","NAME","PRICE","RATING") values
(1,0,'phone with high resolution and front and rare camers','https://cdn0.vox-cdn.com/hermano/verge/product/image/9019/akrales_190307_3272_0020_squ.jpg','SAMSUNG',11000,0),
(2,0,'available with multicolors','https://rukminim1.flixcart.com/image/714/857/k1i6ikw0/shoe/r/m/g/bq3204-002-7-nike-black-white-anthracite-original-imafh2hv38ygyyfy.jpeg?q=50','Nike',5000,0),
(3,0,'gorilla glass with triple camera','https://cdn0.vox-cdn.com/hermano/verge/product/image/9180/vpavic_190924_3684_0068_squ.jpg','ONEPLUS',35000,0),
(4,0,'available for manual colors and in different styles','https://rukminim1.flixcart.com/image/714/857/jmwch3k0/shoe/j/y/n/dg-292-white-blue-patti-10-digitrendzz-white-original-imaf9p36fkykfjqt.jpeg?q=50','ADIDAS',5000,0),
(5,0,'tracks daily activities','https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1574443823-best-fitness-trackers-watches-for-women-letscom-1574443794.jpg','FITNESS',8000,0),
(6,0,'available with leather belts','https://rukminim1.flixcart.com/image/714/857/k1i6ikw0/shoe/r/m/g/bq3204-002-7-nike-black-white-anthracite-original-imafh2hv38ygyyfy.jpeg?q=50','Nike',5000,0),
(7,0,'available with best specs and best colors','https://cdn0.vox-cdn.com/hermano/verge/product/image/9180/vpavic_190924_3684_0068_squ.jpg','MOTOROLA',35000,0);
