package com.retail.product.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.retail.product.client.AuthClient;
import com.retail.product.exception.AccessUnauthorizedException;
import com.retail.product.exception.ProductNotFoundException;
import com.retail.product.model.Product;
import com.retail.product.service.ProductService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
//@WithMockUser
//@PreAuthorize("authenticated")
public class ProductControllerTest {

	@Autowired
	private MockMvc mock;
	@MockBean
	ProductService productService;
	@MockBean
	private AuthClient authClient;

	ObjectMapper mapper=new ObjectMapper();
	/// search product by id
	//@PreAuthorize("authenticated")
	//@Test
	//@WithMockUser(username = "1", password = "1")
	
	@Test
	public void test() throws Exception {
		MvcResult mvcResult = mock.perform(get("/test").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		//assertEquals(true, mvcResult.getResponse().getContentAsString().contains("OK"));
	}

	@Test
	public void testSearchProductById() throws Exception {
		
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(productService.getProductId(1)).thenReturn(Optional.of(p));
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/searchProductById/1").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Shoes"));
	}
	@Test
	public void testSearchProductByIdProductNotFoundException() throws Exception {
		
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(productService.getProductId(1)).thenReturn(Optional.empty());
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/searchProductById/1").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(404, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Product with id=:1 was not found."));
	}

	@Test
	public void testSearchProductByIdAccessUnauthorizedException() throws Exception {
		
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(productService.getProductId(1)).thenReturn(Optional.of(p));
		when(authClient.getValidity("Bearer token")).thenReturn(false);
		MvcResult mvcResult = mock.perform(get("/api/searchProductById/1").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(403, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Invalid token"));
	}

	
	// search product by name
	@Test
	public void testSearchProductByName()
			throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProductName("shoe")).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/searchProductByName/shoe").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Shoes"));
		
	}
	@Test
	public void testSearchProductByNameProductNotFoundException()
			throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProductName("shoe")).thenReturn(new ArrayList<Product>());
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/searchProductByName/shoe").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(404, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Product with name=:shoe was not found."));
		
	}
	@Test
	public void testSearchProductByNameAccessUnauthorizedException()
			throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProductName("shoe")).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(false);
		MvcResult mvcResult = mock.perform(get("/api/searchProductByName/shoe").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(403, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Invalid token"));
		
	}
	// get rating from the user
	@Test
	public void testAddProductRating()
			throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		//when( productService.addRatings(1,3)).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(post("/api/addProductRating/1/3").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Rating submitted successfully."));
		verify(productService).addRatings(1,3);
	}
	@Test
	public void testAddProductRatingAccessUnauthorizedException()
			throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		//when( productService.addRatings(1,3)).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(false);
		MvcResult mvcResult = mock.perform(post("/api/addProductRating/1/3").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(403, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Invalid token"));
		//verify(productService).addRatings(1,3);
	}

	// add a product to the database
	@Test
	public void testCreateProduct() throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		String strProduct=mapper.writeValueAsString(p);
		//when( productService.addRatings(1,3)).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(post("/api/addproduct").header("Authorization", "Bearer token").accept("application/json").contentType("application/json").content(strProduct)).andReturn();
		assertEquals(201, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Product added successfully"));
		//verify(productService).addProduct(p);
		
	}
	@Test
	public void testCreateProductAccessUnauthorizedException() throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		String strProduct=mapper.writeValueAsString(p);
		//when( productService.addRatings(1,3)).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(false);
		MvcResult mvcResult = mock.perform(post("/api/addproduct").header("Authorization", "Bearer token").accept("application/json").contentType("application/json").content(strProduct)).andReturn();
		assertEquals(403, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Invalid token"));
		//verify(productService).addProduct(p);
		
	}

	// get list of al the products
	@Test
	public void testGetProducts() throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProducts()).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/getproducts").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(200, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Shoes"));
	}
	@Test
	public void testGetProductsProductNotFoundException() throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProducts()).thenReturn(new ArrayList<Product>());
		when(authClient.getValidity("Bearer token")).thenReturn(true);
		MvcResult mvcResult = mock.perform(get("/api/getproducts").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(404, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("No products were found"));
	}
	@Test
	public void testGetProductsAccessUnauthorizedException() throws Exception {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when( productService.getProducts()).thenReturn(Arrays.asList(p));
		when(authClient.getValidity("Bearer token")).thenReturn(false);
		MvcResult mvcResult = mock.perform(get("/api/getproducts").header("Authorization", "Bearer token").accept("application/json")).andReturn();
		assertEquals(403, mvcResult.getResponse().getStatus());
		assertEquals(true, mvcResult.getResponse().getContentAsString().contains("Invalid token"));
	}

}