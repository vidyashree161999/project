package com.retail.proceedtobuy.client;

import org.springframework.http.ResponseEntity;

import com.retail.proceedtobuy.DTO.Product;

public class ProductClientFallback implements ProductClient{

	@Override
	public String test() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<Product> searchProductById(String token, int productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
