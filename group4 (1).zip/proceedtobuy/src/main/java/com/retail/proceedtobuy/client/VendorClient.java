package com.retail.proceedtobuy.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.retail.proceedtobuy.DTO.Vendor;

@FeignClient(name = "vendorclient", url = "http://localhost:8083/api", fallback = VendorClientFallback.class)
public interface VendorClient {

	@GetMapping("/getVendorDetails/{productId}/{quantity}")
	public List<Vendor> getVendors(@RequestHeader("Authorization") String token, @PathVariable("productId") int productId,
			@PathVariable("quantity") int quantity);
	@GetMapping("/getDeliveryCharge/{vendorId}")
	public double getDeliveryCharge(@RequestHeader("Authorization") String token,@PathVariable("vendorId") int vendorId);

	
}
