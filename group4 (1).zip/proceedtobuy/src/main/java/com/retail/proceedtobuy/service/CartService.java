package com.retail.proceedtobuy.service;

import java.util.Date;
import java.util.List;

import com.retail.proceedtobuy.DTO.CartRequest;
import com.retail.proceedtobuy.DTO.Product;
import com.retail.proceedtobuy.DTO.Vendor;
import com.retail.proceedtobuy.exception.ProductNotFoundException;

public interface CartService {

	public void addProductToWishlist(int customerId, int productId, int quantity);

	public void deleteFromCart(int customerId, int productId) throws ProductNotFoundException;

	public void deleteFromWishlist(int customerId, int productId) throws ProductNotFoundException;

	List<Product> getWishlist(String token, int customerId);

	List<CartRequest> getCart(String token, int customerId);

	public void updateCart(int customerId, int productId, int qty);

	void addProductToCart(String token, int customerId, int productId, int zipCode, Date expectedDeliveryDate,
			int quantity) throws ProductNotFoundException;

	public double getDeliveryCharge(String token,int customerId);

	public float calculateTotalForCart(String token, int customerId);

	void updateVendor(String token, int customerId, int productId, int qty, int vendorId);

	public List<Vendor> getVendors(String string, int i, int j);

}
