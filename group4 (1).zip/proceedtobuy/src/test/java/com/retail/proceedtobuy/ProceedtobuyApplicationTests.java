package com.retail.proceedtobuy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProceedtobuyApplicationTests {

	@Test
	void contextLoads() {
	}

}
