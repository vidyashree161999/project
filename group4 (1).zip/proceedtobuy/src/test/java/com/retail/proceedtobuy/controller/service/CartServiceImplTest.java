package com.retail.proceedtobuy.controller.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.retail.proceedtobuy.DTO.Product;
import com.retail.proceedtobuy.DTO.Vendor;
import com.retail.proceedtobuy.client.AuthClient;
import com.retail.proceedtobuy.client.ProductClient;
import com.retail.proceedtobuy.client.VendorClient;
import com.retail.proceedtobuy.exception.ProductNotFoundException;
import com.retail.proceedtobuy.model.Cart;
import com.retail.proceedtobuy.model.VendorWishlist;
import com.retail.proceedtobuy.repository.CartRepository;
import com.retail.proceedtobuy.repository.WishListRepository;
import com.retail.proceedtobuy.service.CartService;

@SpringBootTest
class CartServiceImplTest {

	@Autowired
	CartService service;

	@MockBean
	CartRepository repository;

	@MockBean
	WishListRepository wlrepo;

	@MockBean
	ProductClient pc;

	@MockBean
	AuthClient auth;

	@MockBean
	VendorClient vclient;

	@Test
	void testAddProductToWishlist() {
		VendorWishlist vl = new VendorWishlist();
		vl.setCustomerId(1);
		vl.setProductId(1);
		vl.setQuantity(1);
		vl.setAddingDateToWishlist(LocalDate.now());
		service.addProductToWishlist(1, 1, 1);
		// verify(wlrepo).save( any(VendorWishlist.class));
		// when(wlrepo.findByCustomerIdAndProductId(5, 1)).thenReturn(vl);
	}

	@Test
	void testAddProductToCart() throws ProductNotFoundException {
		Product p = new Product(1, "coffee", 85, "desc", "abc", 4, 3);
		// Product p=pc.searchProductById(1);
		List<Vendor> list = new ArrayList<Vendor>();
		list.add(new Vendor(1, "test", 1, 1));
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		when(vclient.getVendors("token", 1, 1)).thenReturn(list);

		Cart c = new Cart(1, 1, 1, 215014, new Date(), 1, 1);
		service.addProductToCart("token", c.getUserId(), p.getId(), c.getZipcode(), c.getDeliveryDate(),
				c.getVendorId());
	}

	@Test
	void testAddProductToCartNoVendors() throws ProductNotFoundException {
		Product p = new Product(1, "coffee", 85, "desc", "abc", 4, 3);
		// Product p=pc.searchProductById(1);
		List<Vendor> list = new ArrayList<Vendor>();
		// list.add(new Vendor(1, "test", 1,1));
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		when(vclient.getVendors("token", 1, 1)).thenReturn(list);
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(new VendorWishlist(1, 1, 1, 1, LocalDate.now()));

		Cart c = new Cart(1, 1, 1, 215014, new Date(), 1, 1);
		service.addProductToCart("token", c.getUserId(), p.getId(), c.getZipcode(), c.getDeliveryDate(),
				c.getVendorId());
	}

	@Test
	void testAddProductToCartNoVendorsNoWishlist() throws ProductNotFoundException {
		Product p = new Product(1, "coffee", 85, "desc", "abc", 4, 3);
		// Product p=pc.searchProductById(1);
		List<Vendor> list = new ArrayList<Vendor>();
		// list.add(new Vendor(1, "test", 1,1));
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		when(vclient.getVendors("token", 1, 1)).thenReturn(list);
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(null);

		Cart c = new Cart(1, 1, 1, 215014, new Date(), 1, 1);
		service.addProductToCart("token", c.getUserId(), p.getId(), c.getZipcode(), c.getDeliveryDate(),
				c.getVendorId());
	}

	@Test
	void testAddProductToCartNoVendorsNoWishlistCartExists() throws ProductNotFoundException {
		Product p = new Product(1, "coffee", 1, "desc", "abc", 1, 1);
		// Product p=pc.searchProductById(1);
		List<Vendor> list = new ArrayList<Vendor>();
		// list.add(new Vendor(1, "test", 1,1));
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		when(vclient.getVendors("token", 1, p.getId())).thenReturn(list);
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(null);
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);
		service.addProductToCart("token", c.getUserId(), p.getId(), c.getZipcode(), c.getDeliveryDate(),
				c.getVendorId());
	}

	@Test
	void testAddProductToCartProductNotFoundException() throws ProductNotFoundException {
		Product p = new Product(1, "coffee", 1, "desc", "abc", 1, 1);
		// Product p=pc.searchProductById(1);
		List<Vendor> list = new ArrayList<Vendor>();
		// list.add(new Vendor(1, "test", 1,1));
		when(pc.searchProductById("token", 1)).thenReturn(null);
		when(vclient.getVendors("token", 1, 1)).thenReturn(list);
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(null);
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);

//		Exception exception = assertThrows(ProductNotFoundException.class,
//				() -> service.addProductToCart("token", 1, 1, 1, c.getDelivery_date(), 1));
//		assertEquals("Product with id=:" + 1 + " was not found.", exception.getMessage());
	}

	@Test
	void testDeleteFromCart() throws ProductNotFoundException {
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);
		service.deleteFromCart(1, 1);
		// repository.delete(c);
		// when(repository.findById(1)).thenReturn(Optional.empty());
	}

	@Test
	void testDeleteFromCartQty() throws ProductNotFoundException {
		Cart c = new Cart(2, 2, 2, 2, new Date(), 2, 2);
		when(repository.findByUserIdAndProductId(2, 2)).thenReturn(c);
		service.deleteFromCart(2, 2);
		// repository.delete(c);
		// when(repository.findById(1)).thenReturn(Optional.empty());
	}

	@Test
	void testDeleteFromCartQtyProductNotFoundException() throws ProductNotFoundException {
		Cart c = new Cart(2, 2, 2, 2, new Date(), 2, 2);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);
		// service.deleteFromCart(2, 2);
		Exception exception = assertThrows(ProductNotFoundException.class, () -> service.deleteFromCart(2, 2));
		assertEquals("Product with id2is not in the cart.", exception.getMessage());
		// repository.delete(c);
		// when(repository.findById(1)).thenReturn(Optional.empty());
	}

	@Test
	void testDeleteFromWishlist() throws ProductNotFoundException {
		VendorWishlist vl = new VendorWishlist(1, 1, 1, 1, LocalDate.now());
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(vl);
		service.deleteFromWishlist(1, 1);
		// when(wlrepo.findById(41)).thenReturn(Optional.empty());
	}

	@Test
	void testDeleteFromWishlistNotFound() throws ProductNotFoundException {
		VendorWishlist vl = new VendorWishlist(1, 1, 1, 1, LocalDate.now());
		when(wlrepo.findByCustomerIdAndProductId(1, 1)).thenReturn(null);
		service.deleteFromWishlist(1, 1);
		// when(wlrepo.findById(41)).thenReturn(Optional.empty());
	}

	@Test
	void testGetCart() {
		List<Cart> c = new ArrayList<>();
		c.add(new Cart(1, 1, 1, 1, new Date(), 1, 1));
		Product p = new Product(1, "1", 1, "1", "1", 1, 1);
		when(repository.findByUserId(1)).thenReturn(c);
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		assertEquals(service.getCart("token", 1).get(0).getCustomerId(), 1);
	}

	@Test
	void testGetWishlist() {
		List<VendorWishlist> wl = new ArrayList<>();
		wl.add(new VendorWishlist(1, 1, 1, 1, LocalDate.now()));
		when(wlrepo.findByCustomerId(1)).thenReturn(wl);
		Product p = new Product(1, "1", 1, "1", "1", 1, 1);
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		assertEquals(service.getWishlist("token", 1).get(0).getId(), 1);
	}

	@Test
	void testUpdateCart() {
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);
		service.updateCart(1, 1, 1);
	}

	@Test
	void testUpdateCartNoCart() {
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(null);
		service.updateCart(1, 1, 1);
	}

	@Test
	void testUpdateCartQty0() {
		Cart c = new Cart(1, 1, 1, 1, new Date(), 1, 1);
		when(repository.findByUserIdAndProductId(1, 1)).thenReturn(c);
		service.updateCart(1, 1, 0);
	}

	@Test
	void testUpdateVendor() {
		List<Vendor> vendors = new ArrayList<Vendor>();
		vendors.add(new Vendor(1, "1", 1, 1));
		vendors.add(new Vendor(2, "2", 2, 2));
		when(vclient.getVendors("token", 2, 2)).thenReturn(vendors);
		when(repository.findByUserIdAndProductId(2, 2)).thenReturn(new Cart(2, 2, 2, 2, new Date(), 2, 2));
		service.updateVendor("token", 2, 2, 2, 2);

	}

	@Test
	void testUpdateVendorNoVendor() {
		List<Vendor> vendors = new ArrayList<Vendor>();
		// vendors.add(new Vendor(1, "1", 1, 1));
		// vendors.add(new Vendor(2, "2", 2, 2));
		when(vclient.getVendors("token", 2, 2)).thenReturn(vendors);
		when(repository.findByUserIdAndProductId(2, 2)).thenReturn(new Cart(2, 2, 2, 2, new Date(), 2, 2));
		service.updateVendor("token", 2, 2, 2, 2);

	}

	@Test
	void testGetVendors() {
		List<Vendor> vendors = new ArrayList<Vendor>();
		vendors.add(new Vendor(1, "1", 1, 1));
		when(vclient.getVendors("token", 1, 1)).thenReturn(vendors);
		assertEquals(service.getVendors("token", 1, 1).get(0).getVendorId(), 1);

	}

	@Test
	void testGetDeliveryCharge() {
		List<Cart> c = new ArrayList<>();
		c.add(new Cart(1, 1, 1, 1, new Date(), 1, 1));
		when(repository.findByUserId(1)).thenReturn(c);
		when(vclient.getDeliveryCharge("token", 1)).thenReturn((double) 1);
		assertEquals(service.getDeliveryCharge("token", 1), 1);
	}

	@Test
	void testCalculateTotalForCart() {
		List<Cart> c = new ArrayList<>();
		c.add(new Cart(1, 1, 1, 1, new Date(), 1, 1));
		Product p = new Product(1, "1", 1, "1", "1", 1, 1);
		when(repository.findByUserId(1)).thenReturn(c);
		when(pc.searchProductById("token", 1)).thenReturn(new ResponseEntity<Product>(p, HttpStatus.OK));
		assertEquals(service.calculateTotalForCart("token", 1), 1);
	}
	/************
	 * 
	 * @Test
	 * 
	 *       void testDeleteFromCartNotFound() {
	 * 
	 *       when(repository.findById(99)).thenReturn(Optional.empty());
	 * 
	 *       Exception exception = assertThrows(ProductNotFoundException.class, ()
	 *       -> service.deleteFromCart(13, 5));
	 * 
	 *       assertEquals("Product with id5is not in the cart.",
	 *       exception.getMessage());
	 * 
	 *       }*****
	 * 
	 * @Test
	 * 
	 *       void testAddProductToCartNotDone() {
	 * 
	 *       when(pc.searchProductById(5)).thenReturn(null);
	 * 
	 *       assertThrows(ProductNotFoundException.class, () ->
	 *       service.addProductToCart(20, 5, 52140, new Date(), 7));
	 * 
	 *       }
	 */
}
