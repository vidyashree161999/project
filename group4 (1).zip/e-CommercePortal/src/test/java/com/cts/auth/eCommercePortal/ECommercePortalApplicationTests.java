package com.cts.auth.eCommercePortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommercePortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
