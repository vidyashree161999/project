package com.cts.eCommercePortal.model;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data 
@NoArgsConstructor
@AllArgsConstructor
public class VendorWishlist {
	private int wishlistId;
	private int customerId;
	private int productId;
	private int quantity;
	private LocalDate addingDateToWishlist;
}
