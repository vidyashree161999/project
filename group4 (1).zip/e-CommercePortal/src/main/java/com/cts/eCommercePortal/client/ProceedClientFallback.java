package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.CartRequest;
import com.cts.eCommercePortal.model.Product;

public class ProceedClientFallback implements ProceedClient{

	@Override
	public List<Product> getWishlist(String token, int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String test() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CartRequest> getCart(String token, int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<String> deleteProductFromCart(String token, int customerId, int productId)
			throws ProductNotFoundException, AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<String>  updateCart(String token, int customerId, int productId, int qty) {
		return null;
		// TODO Auto-generated method stub
		
	}

	@Override
	public ResponseEntity<String>  addProductToCart(String token, int customerId, int productId, int zipCode,
			String expectedDeliveryDate) throws ProductNotFoundException, AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<String>  updateVendor(String token, int customerId, int productId, int qty, int vendorId) {
		return null;
		// TODO Auto-generated method stub
		
	}

	@Override
	public ResponseEntity<Double> getDeliveryCharge(String token, int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<Float> calculateTotalForCart(String token, int customerId)
			throws AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}

}
