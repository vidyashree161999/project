package com.cts.eCommercePortal.client;

import com.cts.eCommercePortal.model.UserAuth;
import com.cts.eCommercePortal.model.UserLoginCredential;

public class AuthClientFallback implements AuthClient {

	@Override
	public boolean getValidity(String token) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getId(String token) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String test() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String login(UserLoginCredential userlogincredentials) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String register(UserAuth userAuth) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getZip(String token) {
		// TODO Auto-generated method stub
		return 0;
	}

	

}
