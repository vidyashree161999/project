package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.Product;

//@Headers("Content-Type: application/json")
@FeignClient(name = "productclient", url = "http://localhost:8081/api", fallback = ProductClientFallback.class)
//@FeignClient(url="http://localhost:8081/api/")
public interface ProductClient {
	@GetMapping("/getproducts")
	public List<Product> getProduct(@RequestHeader("Authorization") String token);
	
	@GetMapping("/searchProductByName/{name}")
	public List<Product> searchProductByName(@RequestHeader("Authorization") String token,@PathVariable("name") String name)
			throws ProductNotFoundException, AccessUnauthorizedException;

	@PostMapping("/addProductRating/{id}/{rating}")
	public ResponseEntity<String> addProductRating(@RequestHeader("Authorization") String token,@PathVariable("id") int id, @PathVariable("rating") float rating)
			throws ProductNotFoundException, AccessUnauthorizedException;

	@GetMapping("test")
	public String test();
}
