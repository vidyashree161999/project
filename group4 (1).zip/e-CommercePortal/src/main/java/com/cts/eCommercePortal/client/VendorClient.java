package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.model.Vendor;

@FeignClient(name = "vendorclient", url = "http://localhost:8083/api", fallback = VendorClientFallback.class)

public interface VendorClient {
	@GetMapping(value="/getVendorDetails/{productId}/{quantity}" )
	public ResponseEntity<List<Vendor>> getVendors(@RequestHeader("Authorization") String token,@PathVariable int productId, @PathVariable int quantity) throws AccessUnauthorizedException;
}
