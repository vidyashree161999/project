package com.retail.authorization;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.retail.authorization.service.CustomerDetailsService;
import com.retail.authorization.util.JwtUtil;
@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {
	@Autowired
	private MockMvc mock;
	@MockBean
	CustomerDetailsService custdetailservice;
	@MockBean
	JwtUtil jwtutil;
	@Test
	void testTest() {
	}


	@Test
	void testGetValidity() throws Exception {
		
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/validate").header("Authorization", "token").accept("application/json")).andReturn();
			//.andExpect(status().isOk());
	}

	@Test
	void testGetId() throws Exception {
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/getId").header("Authorization", "token").accept("application/json")).andReturn();
	}

	@Test
	void testGetZip() throws Exception {
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/getZip").header("Authorization", "token").accept("application/json")).andReturn();
		
	}

}