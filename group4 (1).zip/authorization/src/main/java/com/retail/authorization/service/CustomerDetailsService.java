package com.retail.authorization.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.retail.authorization.exception.UserAlreadyExistsException;
import com.retail.authorization.model.UserAuth;

public interface CustomerDetailsService extends UserDetailsService {

	boolean addUser(UserAuth userAuth) throws UserAlreadyExistsException;

	int getId(String extractUsername);

	UserAuth getUser(String extractUsername);
	
	

}