package com.retail.authorization.service.impl;


import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.retail.authorization.dao.UserDAO;
import com.retail.authorization.exception.UserAlreadyExistsException;
import com.retail.authorization.model.UserAuth;
import com.retail.authorization.service.CustomerDetailsService;


@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

	@Autowired
	private UserDAO userdao;
	
	@Override
	public UserDetails loadUserByUsername(String uname) throws UsernameNotFoundException {

		UserAuth custuser=userdao.findByUname(uname)
				.orElseThrow( ()->new UsernameNotFoundException("Username: "+uname+" doesnt exist."));
		
		return new User(custuser.getUname(), custuser.getUpassword(), new ArrayList<>());
		
		
	}
	
	@Override
	public boolean addUser(UserAuth userAuth) throws UserAlreadyExistsException {
		if(userdao.findByUname(userAuth.getUname())==null)
			throw new UserAlreadyExistsException("User with username:"+userAuth.getUname()+" already exists");
		if(userdao.save(userAuth)!=null)
			return true;
		
		return false;
	}

	@Override
	public int getId(String extractUsername) {
		// TODO Auto-generated method stub
		return (int) userdao.findByUname(extractUsername).get().getUserid();
	}

	@Override
	public UserAuth getUser(String extractUsername) {
		// TODO Auto-generated method stub
		return userdao.findByUname(extractUsername).get();
	}

}
