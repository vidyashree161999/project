INSERT INTO "PUBLIC"."USER" 
values (1, 'bangalore','siddarth@gmail.com','siddarth','a','siddu','123',564323),
(2, 'chennai','anitha@gmail.com','anitha','a','anitha','123',231234),
(3, 'hyderabad','sujan@gmail.com','sujan','a','sujan','123',674534),
(4, 'kochi','sreeja@gmail.com','sreeja','a','sreeja','123',986547)
;